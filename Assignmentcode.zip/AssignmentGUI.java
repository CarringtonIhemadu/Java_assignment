
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *  Name;carrington ihemadu
 *  Student Number;C16341401
 *  Description; This is my main assignment GUI class, it is the interface of an ATM
 *               it shows the user options that they can select from, then continues to carry
 *               out the functions (withdraw, view account balance, deposit, Exit, view account
 *               , and update account.
 * 
 * 
 */
public class AssignmentGUI extends javax.swing.JFrame
{
    String ACC_NUM;
  
    
    

    /**
     * Creates new form AssignmentGUI taking in the account number from the login
     * Screen.
     */

    public AssignmentGUI(String ACC_NUM)
    {
        this.ACC_NUM = ACC_NUM;
        initComponents();
    }

    //the next block of code is used to create and add components to the GUI
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        ACCOUNTBALANCE = new javax.swing.JButton();
        DEPOSIT = new javax.swing.JButton();
        WITHDRAWAL = new javax.swing.JButton();
        CHANGEPIN = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        EXIT = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        update_account = new javax.swing.JButton();
        view_account = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Carrots ATM simulator");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(559, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel2.setText("Main Menu");

        ACCOUNTBALANCE.setText("SELECT");
        ACCOUNTBALANCE.setToolTipText("CHECK ACCOUNT BALANCE");
        ACCOUNTBALANCE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ACCOUNTBALANCEActionPerformed(evt);
            }
        });

        DEPOSIT.setText("SELECT");
        DEPOSIT.setToolTipText("MAKE A DEPOSIT");
        DEPOSIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DEPOSITActionPerformed(evt);
            }
        });

        WITHDRAWAL.setText("SELECT");
        WITHDRAWAL.setToolTipText("MAKE A WITHDRAWAL");
        WITHDRAWAL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WITHDRAWALActionPerformed(evt);
            }
        });

        CHANGEPIN.setText("SELECT");
        CHANGEPIN.setToolTipText("CHANGE PIIN CODE");
        CHANGEPIN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CHANGEPINActionPerformed(evt);
            }
        });

        jLabel3.setText("Check account balance");

        jLabel4.setText("Make a deposit");

        jLabel5.setText("Make a withdrawal");

        jLabel6.setText("Change passcode");

        jLabel7.setText("Exit ?");

        EXIT.setText("YES");
        EXIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EXITActionPerformed(evt);
            }
        });

        jLabel8.setText("update account details");

        jLabel9.setText("view account details");

        update_account.setText("SELECT");
        update_account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_accountActionPerformed(evt);
            }
        });

        view_account.setText("SELECT");
        view_account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_accountActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel10.setText("-Enter the date in this format; \" 2018-06-29\"");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel11.setText("-you must enter at least one character into the chosen field");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel3))
                                .addGap(109, 109, 109)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(WITHDRAWAL, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                                    .addComponent(CHANGEPIN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(DEPOSIT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ACCOUNTBALANCE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(view_account, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(update_account, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel10))
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(EXIT)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ACCOUNTBALANCE, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(view_account, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DEPOSIT, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update_account, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(WITHDRAWAL, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(EXIT)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addGap(13, 13, 13)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CHANGEPIN, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    //this method is used to allow the user to withdraw money from their account 
    //it uses a connection to a database to access the users account balance.
    private void WITHDRAWALActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WITHDRAWALActionPerformed
        
        //this next line of code prompts the user for a withdraw amount 
        String input = JOptionPane.showInputDialog("enter your withdraw amount");
        int withdraw_amt = Integer.valueOf(input);
        
        //using a try catch pair this block of code attempts to connect to the database
        try
        {  
            //creating a connection variable and setting it to get connection to the database
            //then creating a statement variable so we can exequte queries in the database
            //then creating a result set of everything inside the database table 
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from USER_DETAIL");
            
            //uisng a while statement to read to the result set
            while(rs.next())
            {
                //check the result set for the account number 
                if(rs.getString(7).equals(ACC_NUM))
                {
                    //take the balacance and change it into an int
                    String balance = rs.getString(6);
                    int balance2 = Integer.valueOf(balance);
                    
                    //if the withdraw amount is greater than the account balance then withdraw declined 
                    if(balance2<withdraw_amt)
                    {
                        JOptionPane.showMessageDialog(this, "withdraw declined (account balance too low)");
                    }
                    
                    //else perform calculation and then use the st variable to execute the SQL query
                    else
                    {
                        int new_balance = balance2 - withdraw_amt;
                    
                        st.addBatch("UPDATE USER_DETAIL SET ACCBALANCE = "+new_balance+" WHERE user_detail.accnum = '"+ACC_NUM+"'");
                        st.executeBatch();
                        JOptionPane.showMessageDialog(this, "withdraw successful");
                    }
                }
            }
        }
        
        catch(SQLException ex)
        {
            
        }
    }//GEN-LAST:event_WITHDRAWALActionPerformed
    
    
    
    
    
/*
this method allows the user to connect to the database and view their account balance    
*/
    private void ACCOUNTBALANCEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ACCOUNTBALANCEActionPerformed
        //using a try catch pair this block of code attempts to connect to the database
        try
        {
            //creating a connection variable and setting it to get connection to the database
            //then creating a statement variable so we can exequte queries in the database
            //then creating a result set of everything inside the database table 
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from USER_DETAIL");
            
            //uisng a while statement to read to the result set
            while(rs.next())
            {
                //check database for the account number 
                if(rs.getString(7).equals(ACC_NUM))
                {   
                    //convert the taken account balance from the data base to int 
                    //and display to user
                    String balance = rs.getString(6);
                    int balance2 = Integer.valueOf(balance);
                    JOptionPane.showMessageDialog(this, "the current account balance: " +balance2);
                    
                }
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_ACCOUNTBALANCEActionPerformed

    /*
        this method allows the user to deposit a chosen amount into their account 
        by connecting to their account in the data base and making the transaction
    */
    private void DEPOSITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DEPOSITActionPerformed
    String input = JOptionPane.showInputDialog("enter your deposit amount");
    int deposit_amt = Integer.valueOf(input);
       
        //using a try catch pair this block of code attempts to connect to the database
        try
        {
            //creating a connection variable and setting it to get connection to the database
            //then creating a statement variable so we can exequte queries in the database
            //then creating a result set of everything inside the database table 
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from USER_DETAIL");
            
            //uisng a while statement to read to the result set
            while(rs.next())
            {
                //check the database for the account number 
                if(rs.getString(7).equals(ACC_NUM))
                {
                    //get the balance of the account
                    //convert the balance to an int
                    //perform the addition to the database
                   
                    String balance = rs.getString(6);
                    int balance2 = Integer.valueOf(balance);
                    int new_balance = balance2 + deposit_amt;
                    
                    //using st variable add new balance back into the database
                    st.addBatch("UPDATE USER_DETAIL SET ACCBALANCE = "+new_balance+" WHERE user_detail.accnum = '"+ACC_NUM+"'");
                    st.executeBatch();
                    JOptionPane.showMessageDialog(this, "deposit successful");
                        
                    
                }
            }
        }
        
        catch(SQLException ex)
        {
            
        }

    }//GEN-LAST:event_DEPOSITActionPerformed
    
    /*
        This method closes the current GUI and creates a new object of another GUI
    */
    private void EXITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EXITActionPerformed
        LoginGUI GUI1 = new LoginGUI();
        GUI1.setVisible(true);
        dispose();
    }//GEN-LAST:event_EXITActionPerformed

    private void CHANGEPINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CHANGEPINActionPerformed
        String input = JOptionPane.showInputDialog("enter your current passcode");
        
        //using a try catch pair this block of code attempts to connect to the database
        try
        {
            //creating a connection variable and setting it to get connection to the database
            //then creating a statement variable so we can exequte queries in the database
            //then creating a result set of everything inside the database table 
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from USER_DETAIL");
            
            //uisng a while statement to read to the result set
            while(rs.next())
            {
                //checks the database for a matching account number and current passcode compared to the details in the database
                //then allows the user to enter their passcode two times
                if(rs.getString(7).equals(ACC_NUM) && rs.getString(5).equals(input))
                {   
                    String input2 = JOptionPane.showInputDialog("enter your new passcode");
                    String input3 = JOptionPane.showInputDialog("enter your new passcode again");
                    
                    //check if the two passcodes entered were the same
                    if(input2.equals(input3))
                    {
                        //adds the new password to the database for the current account
                        st.addBatch("UPDATE USER_DETAIL SET PASSCODE = '"+input2+"' WHERE user_detail.accnum = '"+ACC_NUM+"' ");
                        st.executeBatch();
                        JOptionPane.showMessageDialog(this, "passcode updated");
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(this, "your two passwords do not match please try again");
                        break;
                    }
                    break;
                }
                else
                {
                    //JOptionPane.showMessageDialog(this, "please enter a correct current passcode");
                }
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(this, ex);
        }
      
    }//GEN-LAST:event_CHANGEPINActionPerformed

    private void view_accountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_accountActionPerformed
        
        //using a try catch pair this block of code attempts to connect to the database
        try
        {
            //creating a connection variable and setting it to get connection to the database
            //then creating a statement variable so we can exequte queries in the database
            //then creating a result set of everything inside the database table 
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from USER_DETAIL");
            
            //uisng a while statement to read to the result set
            while(rs.next())
            {
                //checks for the account inside the database 
                if(rs.getString(7).equals(ACC_NUM))
                {
                    //takes the details from the database and displays them to the user 
                    String Fname = rs.getString(1);
                    String Sname = rs.getString(2);
                    String D_O_B = rs.getString(3);
                    String ACC_type = rs.getString(4);
                    
                    JOptionPane.showMessageDialog(this, "First name: "+Fname+"\nSecond name: "+Sname+"\nDate of birth: "+D_O_B+"\nAccount type: "+ACC_type);
                }
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(this, ex);
        } 
    }//GEN-LAST:event_view_accountActionPerformed

    private void update_accountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_accountActionPerformed
        String input = JOptionPane.showInputDialog("what field would you like to update?");
        
        //checks if the user input is first name or a selected variation
        if (input.equals("first name") || input.equals("firstname") || input.equals("First Name") || input.equals("First name") || input.equals("first Name"))
        {
            //prompts the user for a new firstname
            String firstname = JOptionPane.showInputDialog("enter the name you would like");
            if(firstname.length()>0)
            {
                //using a try catch pair this block of code attempts to connect to the database
                try
                {
                    //creating a connection variable and setting it to get connection to the database
                    //then creating a statement variable so we can exequte queries in the database
                    //then creating a result set of everything inside the database table 
                    Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("select * from USER_DETAIL");
                    
                    //uisng a while statement to read to the result set
                    while(rs.next())
                    {
                        //checks the account number is inside the data base 
                        if(rs.getString(7).equals(ACC_NUM))
                        {
                            //add the users new name into the database 
                            st.addBatch("UPDATE USER_DETAIL SET FNAME = '"+firstname+"' WHERE user_detail.accnum = '"+ACC_NUM+"' ");
                            st.executeBatch();
                            JOptionPane.showMessageDialog(this, "first name updated");
                        }
                    }
                }
                    
                catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(this, ex);
                }
            }
            else 
            {
                JOptionPane.showMessageDialog(this, "please enter something, the first name was not updated");
            }
        }
        
        //checks the user input compared to a select amount of variations 
        if (input.equals("second name")||input.equals("Second Name")||input.equals("secondname")||input.equals("SecondName"))
        {
            //pro
            String secondname = JOptionPane.showInputDialog("enter your new second name");
            if(secondname.length()>0)
            {
                //using a try catch pair this block of code attempts to connect to the database
                try
                {
                    //creating a connection variable and setting it to get connection to the database
                    //then creating a statement variable so we can exequte queries in the database
                    //then creating a result set of everything inside the database table 
                    Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("select * from USER_DETAIL");
                    
                    //uisng a while statement to read to the result set
                    while(rs.next())
                    {
                        //checks the account number in the database 
                        if(rs.getString(7).equals(ACC_NUM))
                        {
                            
                            st.addBatch("UPDATE USER_DETAIL SET SNAME = '"+secondname+"' WHERE user_detail.accnum = '"+ACC_NUM+"' ");
                            st.executeBatch();
                            JOptionPane.showMessageDialog(this, "first name updated");
                        }
                    }
                }
                    
                catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(this, ex);
                }
            }
            else 
            {
                JOptionPane.showMessageDialog(this, "please enter something, the second name was not updated");
            }
        }
        
        //checks the user input compared to the variations allowed 
        if (input.equals("date of birth")|| input.equals("Date Of Birth") || input.equals("dob") || input.equals("DOB") )
        {
            //prompts the user for a new date of birth
            String dob = JOptionPane.showInputDialog("enter new date of birth");
            if(dob.length()>0)
            {
                //using a try catch pair this block of code attempts to connect to the database
                try
                {
                    //creating a connection variable and setting it to get connection to the database
                    //then creating a statement variable so we can exequte queries in the database
                    //then creating a result set of everything inside the database table 
                    Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("select * from USER_DETAIL");
                    
                    //uisng a while statement to read to the result set
                    while(rs.next())
                    {
                        //checks for the users account number inside the database 
                        if(rs.getString(7).equals(ACC_NUM))
                        {
                            //adds the new date of birth to the database
                            st.addBatch("UPDATE USER_DETAIL SET DOB = '"+dob+"' WHERE user_detail.accnum = '"+ACC_NUM+"' ");
                            st.executeBatch();
                            JOptionPane.showMessageDialog(this, "first name updated");
                        }
                    }
                }
                    
                catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(this, ex);
                }
            }
            else 
            {
                JOptionPane.showMessageDialog(this, "please enter something, the date of birth was not updated");
            }
        }
        
        // checks the user input against the allowed variations 
        if (input.equals("account type") || input.equals("Account type") || input.equals("ACCTYPE"))
        {
            String acctype = JOptionPane.showInputDialog("what is your new account type business or personal?");
            if(acctype.length()>0 && (acctype.equals("business") || acctype.equals("personal")))
            {
                //using a try catch pair this block of code attempts to connect to the database
                try
                {
                    //creating a connection variable and setting it to get connection to the database
                    //then creating a statement variable so we can exequte queries in the database
                    //then creating a result set of everything inside the database table 
                    Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Atm_login","C16341401","CIHEMADU");
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("select * from USER_DETAIL");
                    
                    //uisng a while statement to read to the result set
                    while(rs.next())
                    {
                        //checks the account numbe inside the database
                        if(rs.getString(7).equals(ACC_NUM))
                        {
                            ////updates the user account type inside the database 
                            st.addBatch("UPDATE USER_DETAIL SET ACCTYPE = '"+acctype+"' WHERE user_detail.accnum = '"+ACC_NUM+"' ");
                            st.executeBatch();
                            JOptionPane.showMessageDialog(this, "first name updated");
                        }
                    }
                }
                    
                catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(this, ex);
                }
            }
            else 
            {
                JOptionPane.showMessageDialog(this, "please enter a valid account type, the account type was not updated");
            }
        }
        
        else
        {
            JOptionPane.showMessageDialog(this, "please enter a valid option");
        }
        
    }//GEN-LAST:event_update_accountActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ACCOUNTBALANCE;
    private javax.swing.JButton CHANGEPIN;
    private javax.swing.JButton DEPOSIT;
    private javax.swing.JButton EXIT;
    private javax.swing.JButton WITHDRAWAL;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton update_account;
    private javax.swing.JButton view_account;
    // End of variables declaration//GEN-END:variables
}
