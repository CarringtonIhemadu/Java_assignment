/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *  Name;carrington ihemadu
 *  Student Number;C16341401
 *  Description; This is my main class, it creates an instance for 
 *  the loginGUI class and sets it to visible
 * 
 * 
 */
public class Main 
{

    public static void main(String[] args) 
    {
        LoginGUI GUI1 = new LoginGUI();
        GUI1.setVisible(true);
    }
}